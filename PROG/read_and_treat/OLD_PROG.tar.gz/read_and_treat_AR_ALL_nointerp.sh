#!/bin/bash

rm PWV_TREATED_* RH_TREATED_* SEE_TREATED_* TAU_TREATED_* TEMP_TREATED_* WD_TREATED_* WS_TREATED_* -rf
rm *.dat -f

JOB=read_and_treat_AR_exclusive
JOBWD=read_and_treat_AR_exclusive_WD

#LISTGG="night day"
LISTGG="night"

#LISTHH="1H 2H 3H 4H 5H 6H"
LISTHH="1H"

for daygg in $LISTGG; do
  GG="${daygg}"
  rm -rf "${GG}"

#################################################################
#  FILEPATH="/home/turchi/WORKSPACE/SYNC/PARANAL/METEO/DATA/AUTOREGRESSION/PRODUCETREATED/VALERIO/TREATED_${GG}/DAT_ARCHIVE/"
  if [ $GG = night ]; then
    FILEPATH='/home/report/DATA/DA_TRATTARE/dati_night/'
  elif [ $GG = day ]; then
    FILEPATH='/home/report/DATA/DA_TRATTARE/dati_day/'
  else
    echo "ops some problem"
    exit 1;
  fi
#################################################################

  for hiter in $LISTHH; do
    #START and END of minutes to read consecutively
    if [ $hiter == "1H" ]; then
      MAXMIN=60
      MINMIN=1
    fi
    if [ $hiter == "2H" ]; then
      MAXMIN=120
      MINMIN=61
    fi
    if [ $hiter == "3H" ]; then
      MAXMIN=180
      MINMIN=121
    fi
    if [ $hiter == "4H" ]; then
      MAXMIN=240
      MINMIN=181
    fi
    if [ $hiter == "5H" ]; then
      MAXMIN=300
      MINMIN=241
    fi
    if [ $hiter == "6H" ]; then
      MAXMIN=360
      MINMIN=301
    fi
  
    ls "${FILEPATH}"|grep "AR_${GG}.dat"|cut -d"_" -f1|sort|uniq > lista_auto.asc
    LISTA="lista_auto.asc"
    
    #FILEOUT_CUMULATIVE="ALL_obs_mnh_ar_${GG}.txt"
    #test -e ${FILEOUT_CUMULATIVE} && rm ${FILEOUT_CUMULATIVE} -f
    
    rm *_ARevol_*.dat -f
    
    for datenow in $(cat ${LISTA}); do
    
      YEAR=$(echo $datenow|cut -c1-4)
      MONTH=$(echo $datenow|cut -c5-6)
      DAY=$(echo $datenow|cut -c7-8)
    
      DAYNOW=$(date -u -d "${datenow}" +%Y%m%d)
      DATEB=$(date -u -d"$DAYNOW +1day" +%Y%m%d)
    
    
      VARIABLE="SEE-arcsec"
      rm -f AAATMP
      tail -n+3 "${FILEPATH}/${datenow}_see_evol_time_Height_5_20000_TELEMETRY_output_${GG}.dat" > AAATMP
      sed -e 's/NAN/9999.0/g' -i AAATMP
      rm -f ${JOB}
      ./exe90_debug ${JOB}
      ./${JOB}<<EOF
"${datenow}"
"${FILEPATH}/${datenow}_see_evol_time_Height_5_20000_AR_${GG}.dat"
"${FILEPATH}/${datenow}_see_evol_time_Height_5_20000_MNH_${GG}.dat"
"AAATMP"
${MAXMIN}
${MINMIN}
"${VARIABLE}"
"SEE_ARevol_${hiter}_${GG}_${datenow}.dat"
EOF
      rm -f ${JOB}

      VARIABLE="TAU-ms"
      rm -f AAATMP
      tail -n+3 "${FILEPATH}/${datenow}_tau_evol_time_Height_5_20000_TELEMETRY_output_${GG}.dat" > AAATMP
      sed -e 's/NAN/9999.0/g' -i AAATMP
      rm -f ${JOB}
      ./exe90_debug ${JOB}
      ./${JOB}<<EOF
"${datenow}"
"${FILEPATH}/${datenow}_tau_evol_time_Height_5_20000_AR_${GG}.dat"
"${FILEPATH}/${datenow}_tau_evol_time_Height_5_20000_MNH_${GG}.dat"
"AAATMP"
${MAXMIN}
${MINMIN}
"${VARIABLE}"
"TAU_ARevol_${hiter}_${GG}_${datenow}.dat"
EOF
      rm -f ${JOB}

      VARIABLE="GLF-%"
      rm -f AAATMP
      tail -n+3 "${FILEPATH}/${datenow}_glf_evol_time_Height_5_20000_TELEMETRY_output_${GG}.dat" > AAATMP
      sed -e 's/NAN/9999.0/g' -i AAATMP
      rm -f ${JOB}
      ./exe90_debug ${JOB}
      ./${JOB}<<EOF
"${datenow}"
"${FILEPATH}/${datenow}_glf_evol_time_Height_5_20000_AR_${GG}.dat"
"${FILEPATH}/${datenow}_glf_evol_time_Height_5_20000_MNH_${GG}.dat"
"AAATMP"
${MAXMIN}
${MINMIN}
"${VARIABLE}"
"GLF_ARevol_${hiter}_${GG}_${datenow}.dat"
EOF
      rm -f ${JOB}

      VARIABLE="PWV-mm"      
      rm -f AAATMP
      tail -n+3 "${FILEPATH}/${datenow}_wapor_evol_time_Height_5_20000_TELEMETRY_output_${GG}.dat" > AAATMP
      sed -e 's/NAN/9999.0/g' -i AAATMP
      rm -f ${JOB}
      ./exe90_debug ${JOB}
      ./${JOB}<<EOF
"${datenow}"
"${FILEPATH}/${datenow}_wapor_evol_time_Height_5_20000_AR_${GG}.dat"
"${FILEPATH}/${datenow}_wapor_evol_time_Height_5_20000_MNH_${GG}.dat"
"AAATMP"
${MAXMIN}
${MINMIN}
"${VARIABLE}"
"PWV_ARevol_${hiter}_${GG}_${datenow}.dat"
EOF
      rm -f ${JOB}

      VARIABLE="RH-%"
      rm -f AAATMP
      tail -n+3 "${FILEPATH}/${datenow}_rh_k6_evol_time_TELEMETRY_output_${GG}.dat" > AAATMP
      sed -e 's/NAN/9999.0/g' -i AAATMP
      rm -f ${JOB}
      ./exe90_debug ${JOB}
      ./${JOB}<<EOF
"${datenow}"
"${FILEPATH}/${datenow}_rh_k6_evol_time_AR_${GG}.dat"
"${FILEPATH}/${datenow}_rh_k6_evol_time_MNH_${GG}.dat"
"AAATMP"
${MAXMIN}
${MINMIN}
"${VARIABLE}"
"RH_ARevol_${hiter}_${GG}_${datenow}.dat"
EOF
      rm -f ${JOB}
   
      VARIABLE="WS-m/s"
      rm -f AAATMP
      tail -n+3 "${FILEPATH}/${datenow}_wind_k6_evol_time_TELEMETRY_output_${GG}.dat" > AAATMP
      sed -e 's/NAN/9999.0/g' -i AAATMP
      rm -f ${JOB}
      ./exe90_debug ${JOB}
      ./${JOB}<<EOF
"${datenow}"
"${FILEPATH}/${datenow}_wind_k6_evol_time_AR_${GG}.dat"
"${FILEPATH}/${datenow}_wind_k6_evol_time_MNH_${GG}.dat"
"AAATMP"
${MAXMIN}
${MINMIN}
"${VARIABLE}"
"WS_ARevol_${hiter}_${GG}_${datenow}.dat"
EOF
      rm -f ${JOB}
    
      VARIABLE="WD-m/s"
      rm -f AAATMP
      tail -n+3 "${FILEPATH}/${datenow}_winddir_k6_evol_time_TELEMETRY_output_${GG}.dat" > AAATMP
      sed -e 's/NAN/9999.0/g' -i AAATMP
      rm -f ${JOBWD}
      ./exe90_debug ${JOBWD}
      ./${JOBWD}<<EOF
"${datenow}"
"${FILEPATH}/${datenow}_winddir_k6_evol_time_AR_${GG}.dat"
"${FILEPATH}/${datenow}_winddir_k6_evol_time_MNH_${GG}.dat"
"AAATMP"
${MAXMIN}
${MINMIN}
"${VARIABLE}"
"WD_ARevol_${hiter}_${GG}_${datenow}.dat"
EOF
      rm -f ${JOBWD}

      rm -f AAATMP

    done

    #for i in $(ls PWV_ARevol_${GG}*.dat|sort); do
    #  tail -n+3 "${i}" >> "${FILEOUT_CUMULATIVE}"
    #done

    test -d "${GG}/${hiter}" || mkdir -p "${GG}/${hiter}"
    
    test -d "SEE_TREATED"|| mkdir "SEE_TREATED"
    /bin/mv SEE_ARevol_${hiter}_${GG}*.dat "SEE_TREATED/"
    test -d "TAU_TREATED"|| mkdir "TAU_TREATED"
    /bin/mv TAU_ARevol_${hiter}_${GG}*.dat "TAU_TREATED/"
    test -d "GLF_TREATED"|| mkdir "GLF_TREATED"
    /bin/mv GLF_ARevol_${hiter}_${GG}*.dat "GLF_TREATED/"
    test -d "PWV_TREATED"|| mkdir "PWV_TREATED"
    /bin/mv PWV_ARevol_${hiter}_${GG}*.dat "PWV_TREATED/"
    test -d "RH_TREATED"|| mkdir "RH_TREATED"
    /bin/mv RH_ARevol_${hiter}_${GG}*.dat "RH_TREATED/"
    test -d "WS_TREATED"|| mkdir "WS_TREATED"
    /bin/mv WS_ARevol_${hiter}_${GG}*.dat "WS_TREATED/"
    test -d "WD_TREATED"|| mkdir "WD_TREATED"
    /bin/mv WD_ARevol_${hiter}_${GG}*.dat "WD_TREATED/"

  
    mv "TAU_TREATED" "${GG}/${hiter}/"
    mv "SEE_TREATED" "${GG}/${hiter}/"
    mv "GLF_TREATED" "${GG}/${hiter}/"
    mv "PWV_TREATED" "${GG}/${hiter}/"
    mv "RH_TREATED" "${GG}/${hiter}/"
    mv "WS_TREATED" "${GG}/${hiter}/"
    mv "WD_TREATED" "${GG}/${hiter}/"

  done
done
